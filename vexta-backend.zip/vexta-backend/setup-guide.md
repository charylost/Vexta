# Vexta — Setup Guide
## From zero to live in ~15 minutes

---

## STEP 1 — Get your Bot Token

1. Go to https://discord.com/developers/applications
2. Click on your existing application (the one you gave me the Client ID for)
3. In the left sidebar click **Bot**
4. If there's no bot yet, click **Add Bot**
5. Click **Reset Token** → copy the token that appears
6. Paste it into your `.env` file as `DISCORD_BOT_TOKEN=`
7. **Under Privileged Gateway Intents** turn ON:
   - ✅ Server Members Intent
   - ✅ Message Content Intent

---

## STEP 2 — Invite the Bot to your Server

1. Still in Developer Portal → left sidebar → **OAuth2 → URL Generator**
2. Under **Scopes** check: `bot`
3. Under **Bot Permissions** check:
   - ✅ Manage Channels
   - ✅ Manage Roles
   - ✅ Send Messages
   - ✅ Read Message History
   - ✅ Embed Links
   - ✅ Create Instant Invite
4. Copy the generated URL at the bottom and open it in your browser
5. Select your Vexta server → Authorise

---

## STEP 3 — Deploy to Railway

1. Go to https://railway.app and sign up (free)
2. Click **New Project → Deploy from GitHub repo**
   - If you haven't pushed to GitHub yet: click **Deploy from local** or use the Railway CLI
   - Easiest option: upload a zip via the Railway CLI (see below)
3. Railway will detect Node.js and run `npm start` automatically

### Using Railway CLI (easiest no-GitHub method):
```
npm install -g @railway/cli
railway login
cd vexta-backend
railway init
railway up
```

4. Once deployed, Railway gives you a URL like:
   `https://vexta-production.up.railway.app`

---

## STEP 4 — Set Environment Variables on Railway

In Railway → your project → **Variables** tab, add each line from your `.env` file:

| Key | Value |
|-----|-------|
| `DISCORD_CLIENT_SECRET` | `sA9Icep1nyL40i2oA5MQyyavHK5Vl3lN` |
| `DISCORD_BOT_TOKEN` | *(the token you copied in Step 1)* |
| `REDIRECT_URI` | `https://YOUR-APP.up.railway.app/auth/callback` |
| `SESSION_SECRET` | *(any random string, e.g. `xj29fkQp1mNvA8z`)* |
| `NODE_ENV` | `production` |

Replace `YOUR-APP` with your actual Railway subdomain.

---

## STEP 5 — Add Redirect URI to Discord Developer Portal

1. Go back to https://discord.com/developers/applications → your app
2. Left sidebar → **OAuth2 → General**
3. Under **Redirects** click **Add Redirect**
4. Paste: `https://YOUR-APP.up.railway.app/auth/callback`
5. Click **Save Changes**

---

## STEP 6 — Test it

1. Visit your Railway URL in a browser
2. Click Purchase on any bot
3. Click "Link Discord Account" — you should get a Discord auth popup
4. After authorising, the modal should continue to payment selection
5. After submitting, check your Discord server — a new ticket channel should appear under a "tickets" category

---

## Troubleshooting

**Bot not creating channels?**
- Make sure the bot role is above the @everyone role in Server Settings → Roles
- Make sure all 5 bot permissions from Step 2 are granted

**OAuth redirect error?**
- Double check the Redirect URI in Developer Portal matches exactly what's in your `.env`
- It must include `/auth/callback` at the end

**Session not persisting?**
- Make sure `NODE_ENV=production` is set in Railway variables
- Railway provides HTTPS by default which is required for secure cookies

---

## File Structure

```
vexta-backend/
├── server.js          ← Express server + Discord bot
├── package.json
├── .env               ← Your secrets (never commit this)
└── public/
    └── index.html     ← Your Vexta website
```
