require('dotenv').config();
const express = require('express');
const session = require('express-session');
const axios = require('axios');
const path = require('path');
const {
  Client,
  GatewayIntentBits,
  PermissionFlagsBits,
  ChannelType,
  EmbedBuilder
} = require('discord.js');

// ─── Config ────────────────────────────────────────────────────────────────
const CONFIG = {
  CLIENT_ID:     '1498038302463496303',
  CLIENT_SECRET: process.env.DISCORD_CLIENT_SECRET,
  BOT_TOKEN:     process.env.DISCORD_BOT_TOKEN,
  GUILD_ID:      '1483402779186823228',
  STAFF_ROLE_ID: '1488129766904303657',
  REDIRECT_URI:  process.env.REDIRECT_URI,
  SESSION_SECRET:process.env.SESSION_SECRET || 'vexta-session-secret-change-me',
  PAYPAL:        'charylost@gmail.com',
  BTC:           'bc1q3katewzqr4afk0ruxt6qeu097xv8qfngh9ppf4',
  LTC:           'LRqeY5e1bnHmDCGjgWesW8gC8dvF7YnfUR',
};

// ─── Discord Bot ────────────────────────────────────────────────────────────
const bot = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers
  ]
});

bot.once('ready', () => {
  console.log(`✅ Bot ready: ${bot.user.tag}`);
});

bot.login(CONFIG.BOT_TOKEN).catch(err => {
  console.error('❌ Bot login failed:', err.message);
});

// ─── Express App ────────────────────────────────────────────────────────────
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: CONFIG.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// ─── Routes ─────────────────────────────────────────────────────────────────

// Check current session user
app.get('/api/me', (req, res) => {
  res.json({ user: req.session.discord || null });
});

// Logout
app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

// Start Discord OAuth2 flow
app.get('/auth/discord', (req, res) => {
  const params = new URLSearchParams({
    client_id:     CONFIG.CLIENT_ID,
    redirect_uri:  CONFIG.REDIRECT_URI,
    response_type: 'code',
    scope:         'identify guilds.join'
  });
  res.redirect(`https://discord.com/api/oauth2/authorize?${params}`);
});

// OAuth2 callback
app.get('/auth/callback', async (req, res) => {
  const { code } = req.query;
  if (!code) return res.redirect('/?error=no_code');

  try {
    // Exchange code for access token
    const tokenRes = await axios.post(
      'https://discord.com/api/oauth2/token',
      new URLSearchParams({
        client_id:     CONFIG.CLIENT_ID,
        client_secret: CONFIG.CLIENT_SECRET,
        grant_type:    'authorization_code',
        code,
        redirect_uri:  CONFIG.REDIRECT_URI
      }),
      { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
    );

    const { access_token } = tokenRes.data;

    // Get Discord user info
    const userRes = await axios.get('https://discord.com/api/users/@me', {
      headers: { Authorization: `Bearer ${access_token}` }
    });

    const user = userRes.data;

    // Save to session
    req.session.discord = {
      id:            user.id,
      username:      user.username,
      discriminator: user.discriminator,
      avatar:        user.avatar,
      access_token
    };

    // Try to silently add user to the guild (they may already be in it)
    try {
      await axios.put(
        `https://discord.com/api/guilds/${CONFIG.GUILD_ID}/members/${user.id}`,
        { access_token },
        {
          headers: {
            Authorization:  `Bot ${CONFIG.BOT_TOKEN}`,
            'Content-Type': 'application/json'
          }
        }
      );
    } catch (_) {
      // Fine — user is likely already in the server
    }

    res.redirect('/?linked=true');
  } catch (err) {
    console.error('OAuth error:', err.response?.data || err.message);
    res.redirect('/?error=auth_failed');
  }
});

// Submit purchase — creates a Discord ticket
app.post('/api/submit-purchase', async (req, res) => {
  if (!req.session.discord) {
    return res.status(401).json({ error: 'Not authenticated with Discord.' });
  }

  const {
    botName,
    duration,
    price,
    currency,
    paymentMethod,
    transactionId
  } = req.body;

  const user = req.session.discord;

  if (!botName || !duration || !price || !paymentMethod || !transactionId) {
    return res.status(400).json({ error: 'Missing required fields.' });
  }

  try {
    const guild = await bot.guilds.fetch(CONFIG.GUILD_ID);
    await guild.members.fetch(); // Cache members

    // Find or create the "tickets" category
    let category = guild.channels.cache.find(
      c => c.type === ChannelType.GuildCategory &&
           c.name.toLowerCase() === 'tickets'
    );

    if (!category) {
      category = await guild.channels.create({
        name: 'tickets',
        type: ChannelType.GuildCategory,
        permissionOverwrites: [
          {
            id:   guild.roles.everyone,
            deny: [PermissionFlagsBits.ViewChannel]
          },
          {
            id:    CONFIG.STAFF_ROLE_ID,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory
            ]
          }
        ]
      });
    }

    // Create ticket channel
    const safeName = user.username.toLowerCase().replace(/[^a-z0-9]/g, '') || 'user';
    const channelName = `ticket-${safeName}-${Date.now().toString().slice(-5)}`;

    const ticketChannel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: category.id,
      permissionOverwrites: [
        {
          id:   guild.roles.everyone,
          deny: [PermissionFlagsBits.ViewChannel]
        },
        {
          id:    user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.AttachFiles
          ]
        },
        {
          id:    CONFIG.STAFF_ROLE_ID,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
            PermissionFlagsBits.ManageMessages,
            PermissionFlagsBits.AttachFiles
          ]
        }
      ]
    });

    // Payment method display info
    const pmInfo = {
      BTC:    { label: 'Bitcoin (BTC)',           emoji: '₿',  color: 0xF7931A },
      LTC:    { label: 'Litecoin (LTC)',           emoji: '◈',  color: 0xB5B5B5 },
      PAYPAL: { label: 'PayPal Friends & Family',  emoji: '🅿️', color: 0x003087 }
    };
    const pm = pmInfo[paymentMethod] || { label: paymentMethod, emoji: '💳', color: 0x00d4ff };

    const avatarURL = user.avatar
      ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`
      : `https://cdn.discordapp.com/embed/avatars/0.png`;

    const embed = new EmbedBuilder()
      .setTitle('🎟️ New Purchase — Awaiting Verification')
      .setColor(pm.color)
      .setThumbnail(avatarURL)
      .addFields(
        { name: '👤 Customer',            value: `<@${user.id}>\n\`${user.username}\``,           inline: true },
        { name: '🤖 Product',             value: `\`${botName}\``,                                inline: true },
        { name: '⏱️ Duration',            value: `\`${duration}\``,                               inline: true },
        { name: '💰 Amount',              value: `\`${price} ${currency}\``,                      inline: true },
        { name: `${pm.emoji} Payment`,    value: `\`${pm.label}\``,                               inline: true },
        { name: '🔗 Transaction / Proof', value: `\`\`\`${transactionId}\`\`\``,                  inline: false }
      )
      .setFooter({ text: 'Vexta • A staff member will verify your payment shortly.' })
      .setTimestamp();

    await ticketChannel.send({
      content: `👋 <@${user.id}> — Welcome! Your ticket has been opened.\n<@&${CONFIG.STAFF_ROLE_ID}> — New purchase to verify!`,
      embeds: [embed]
    });

    res.json({ success: true, channelId: ticketChannel.id });
  } catch (err) {
    console.error('Ticket creation error:', err);
    res.status(500).json({ error: 'Failed to create ticket. Please contact support on Discord.' });
  }
});

// ─── Start ───────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Vexta server running on port ${PORT}`);
});
